import React from "react";

import "./Nav.css";

const Nav = props => {
  return (
    <div className="menu">
      <nav className="main-nav">
        <a href="/">
         
        </a>
        {props.children}
      </nav>
    </div>
  );
};

export default Nav;
